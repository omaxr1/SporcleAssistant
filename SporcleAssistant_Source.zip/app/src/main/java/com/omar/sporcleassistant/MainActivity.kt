package com.omar.sporcleassistant

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCapture = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = TextView(this).apply {
            text = "Sporcle Assistant\\n\\nمساعد قراءة الأسئلة"
            textSize = 23f
            setPadding(24, 32, 24, 16)
        }
        val info = TextView(this).apply {
            text = "النسخة الأولية تقرأ النص الظاهر على الشاشة وتعرضه في نافذة عائمة. الإجابات الذكية تحتاج ربطًا آمنًا بخدمة ذكاء اصطناعي في خطوة لاحقة."
            textSize = 16f
            setPadding(24, 8, 24, 24)
        }
        val overlayButton = Button(this).apply {
            text = "السماح بالظهور فوق التطبيقات"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "الصلاحية مفعلة", Toast.LENGTH_SHORT).show()
            }
        }
        val startButton = Button(this).apply {
            text = "بدء قراءة الشاشة"
            setOnClickListener { requestScreenCapture() }
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            addView(title); addView(info); addView(overlayButton); addView(startButton)
        }
        setContentView(layout)
    }

    private fun requestScreenCapture() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل صلاحية الظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Deprecated in Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("data", data)
            }
            startForegroundService(service)
            Toast.makeText(this, "بدأت قراءة الشاشة. افتح Sporcle Party.", Toast.LENGTH_LONG).show()
        }
    }
}
